package lk.ijse.chicagosystem.controller;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import lk.ijse.chicagosystem.util.DateAndTime;
import lk.ijse.chicagosystem.util.Navigation;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class StoreKeeperController implements Initializable {

    public JFXButton btnOrder;
    public JFXButton btnManageCustomer;
    public Label lblDate;
    public Text txtHour;
    public ImageView imgView;
    public AnchorPane viewInventoryPane;
    public AnchorPane orderViewPane;

    public void viewMenuOnAction(ActionEvent actionEvent) {

    }

    public void manageCustomerOnAction(ActionEvent actionEvent) {

    }

    public void logOutOnAction(ActionEvent actionEvent) throws IOException {
        Navigation.swichNavigation("LoginForm.fxml", actionEvent);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblDate.setText(DateAndTime.dateNow());
        setTime();
    }
    //set Time
    private void setTime() {
        Thread clock = new Thread() {
            public void run() {
                while (true) {
                    DateFormat hour = new SimpleDateFormat("hh:mm:ss");
                    txtHour.setText(hour.format(new Date()));

                    try {
                        sleep(1000);
                    } catch (InterruptedException ex) {
                    }
                }
            }
        };
        clock.start();
    }

}
