package lk.ijse.chicagosystem.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import lk.ijse.chicagosystem.model.EmployeeModel;
import lk.ijse.chicagosystem.to.Employee;
import lk.ijse.chicagosystem.util.DateAndTime;
import lk.ijse.chicagosystem.util.Navigation;
import lk.ijse.chicagosystem.view.tm.EmployeeTM;
import lk.ijse.chicagosystem.view.tm.SalaryTable;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminFormController implements Initializable {
    public Label lblDate;
    public Text txtHour;
    public Label lblEMPID;
    public Label lblC1;
    public Label lblUn;
    public Label lblSalary;
    public Label lblPw;
    public JFXComboBox cmbDesignation;
    public Label lblTime;
    public Label lblDate1;
    public AnchorPane userPane;
    public JFXTextField tfEmpId;
    public JFXTextField tfFName;
    public JFXTextField tfContact;
    public JFXTextField tfUserName;
    public JFXTextField tfPassword;
    public JFXTextField tfAddress;
    public JFXTextField tfSalary;
    public Label lblName;
    public Label lblTotalOrder;
    public Label lblNewCustomers;
    public Label lblEarning;
    public Label lblNoOfVisitors;
    public Pane viewPane;
    public AnchorPane reportPane;
    public AnchorPane salaryPane;
    public ImageView imgWelcome;
    public AreaChart yearlySales;
    public StackedBarChart monthlySales;
    public TableColumn col1EMPID;
    public TableColumn col2Name;
    public TableColumn col3GrossSalary;
    public TableColumn col4TotalDeduction;
    public TableColumn col5NetSalary;
    public JFXButton btnAddNew;
    public JFXButton btnUpdate;
    public JFXButton btnDelete;
    public Button btnclearTextFields;
    public Label lblSalaryError;
    public Label lblAddress;
    public Label lbldesignation;
    public TableView tblManageSalary;

    String[] role = {"Owner", "Manager", "Chef", "Waiter", "Staff", "Other"};

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        btnAddNew.setText("NEW");
        setTime();
        lblDate.setText(DateAndTime.dateNow());

        lblEarning.setText("10,500");
        lblNewCustomers.setText("12");
        lblNoOfVisitors.setText("450");
        lblTotalOrder.setText("200");

        cmbDesignation.getItems().addAll(role);

//        Salary table data
        setTableData();

        col1EMPID.setCellValueFactory(new PropertyValueFactory<>("empId"));
        col2Name.setCellValueFactory(new PropertyValueFactory<>("name"));
        col3GrossSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));

    }



    public void clearTextFields() {
        tfEmpId.clear();
        tfFName.clear();
        tfAddress.clear();
        tfContact.clear();
        cmbDesignation.setValue("");
        tfSalary.clear();
        tfUserName.clear();
        tfPassword.clear();
    }

    //set Time
    private void setTime() {
        Thread clock = new Thread() {
            public void run() {
                while (true) {
                    DateFormat hour = new SimpleDateFormat("hh:mm:ss");
                    txtHour.setText(hour.format(new Date()));

                    try {
                        sleep(1000);
                    } catch (InterruptedException ex) {
                    }
                }
            }
        };
        clock.start();
    }

    public void checkEmpID(KeyEvent keyEvent) {
//        (E0)([1-9]{1,})([0-9]{0,})
        Pattern empIDpattern = Pattern.compile("(E0)([1-9]{0,})");
        Matcher empIDmatcher = empIDpattern.matcher(tfEmpId.getText());
        boolean isMachedUser = empIDmatcher.matches();
        if (!isMachedUser) {
            tfEmpId.requestFocus();
            tfEmpId.setFocusColor(Paint.valueOf("Red"));
            lblEMPID.setText("*Invalid Employee ID (Start with - E0)");

         } else {
            tfEmpId.setFocusColor(Paint.valueOf("#4059a9"));
            lblEMPID.setText("");
        }
    }
    public void checkEmpName1(KeyEvent keyEvent) {
        if (tfFName!=null){
            tfFName.setFocusColor(Paint.valueOf("#4059a9"));
            lblName.setText("");
        }
        if (tfEmpId.getText().isEmpty()) {
            tfEmpId.setFocusColor(Paint.valueOf("Red"));
            lblEMPID.setText("*Employee ID Required");

        } else {
            tfEmpId.setFocusColor(Paint.valueOf("#4059a9"));
        }

    }
    public void onActionAddress(KeyEvent keyEvent) {
        if (tfAddress!=null){
            tfAddress.setFocusColor(Paint.valueOf("#4059a9"));
            lblAddress.setText("");
        }if (tfFName.getText().isEmpty()) {
            tfFName.setFocusColor(Paint.valueOf("Red"));
            lblName.setText("*Employee Name Required");
            lblEMPID.setText("");

        } else {
            tfFName.setFocusColor(Paint.valueOf("#4059a9"));
            lblName.setText("");
        }

    }
    public void cmbclickOnAction(MouseEvent mouseEvent) {
        if (cmbDesignation!=null) {
            cmbDesignation.setFocusColor(Paint.valueOf("#4059a9"));
            lbldesignation.setText("");
        }
        if (tfAddress.getText().isEmpty()) {
            tfAddress.setFocusColor(Paint.valueOf("Red"));
            lblAddress.setText("*Address Required");

        } else {
            tfAddress.setFocusColor(Paint.valueOf("#4059a9"));
            lblAddress.setText("");
        }
    }
    public void checkContact1(KeyEvent keyEvent){
            if (tfContact != null) {
                tfContact.setFocusColor(Paint.valueOf("#4059a9"));
                lblC1.setText("");
            }

            if (cmbDesignation.getItems().isEmpty()) {
                cmbDesignation.setFocusColor(Paint.valueOf("Red"));
                lbldesignation.setText("*You Must Select Designation of Employee !");

            } else {
                cmbDesignation.setFocusColor(Paint.valueOf("#4059a9"));
                lbldesignation.setText("");
            }
        }

    public void checkUN(KeyEvent keyEvent) {
        if (tfUserName != null) {
            tfUserName.setFocusColor(Paint.valueOf("#4059a9"));
            lblUn.setText("");
        }
        if (tfContact.getText().isEmpty()) {
            tfContact.setFocusColor(Paint.valueOf("Red"));
           lblC1.setText("*Contact Number Required");

        } else {
            tfContact.setFocusColor(Paint.valueOf("#4059a9"));
            lblC1.setText("");
        }

    }

    public void checkPW(KeyEvent keyEvent) {
        if (tfPassword != null) {
            tfPassword.setFocusColor(Paint.valueOf("#4059a9"));
            lblPw.setText("");
        }
        if (tfUserName.getText().isEmpty()) {
            tfUserName.setFocusColor(Paint.valueOf("Red"));
            lblUn.setText("*User Name Required");

        } else {
            tfUserName.setFocusColor(Paint.valueOf("#4059a9"));
            lblUn.setText("");
        }

    }

    public void checkSalary(KeyEvent keyEvent) {
        if (tfSalary != null) {
            tfSalary.setFocusColor(Paint.valueOf("#4059a9"));
            lblSalary.setText("");
        }
        if (tfPassword.getText().isEmpty()) {
            tfPassword.setFocusColor(Paint.valueOf("Red"));
            lblPw.setText("*Password Required");

        } else {
            tfPassword.setFocusColor(Paint.valueOf("#4059a9"));
            lblPw.setText("");
        }

    }

    public void enterOnAction(ActionEvent actionEvent) {
    btnAddNew.fire();
    }

    //    Add New User
    public void addNewUserOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        if (btnAddNew.getText().equals("NEW")) {
            btnAddNew.setText("ADD USER");
            nextId();
        } else {
            tfEmpId.setEditable(true);
            String empId = tfEmpId.getText();
            String name = tfFName.getText();
            String userName = tfUserName.getText();
            String password = tfPassword.getText();
            String address = tfAddress.getText();
            String role = String.valueOf(cmbDesignation.getValue());
            int contactNo = Integer.parseInt(tfContact.getText());
            double salary = Double.parseDouble(tfSalary.getText());

            Employee employee = new Employee(empId, name, userName, password, address, role, contactNo, salary);

            final boolean isAdded = EmployeeModel.save(employee);

            if (isAdded) {
                new Alert(Alert.AlertType.CONFIRMATION, "New Employee Added Successful...!").show();
                clearTextFields();
                btnAddNew.setText("NEW");
            }else {
                new Alert(Alert.AlertType.WARNING, "Something Wrong...!").show();
        }
        }
    }

    //    Add New User
    private void nextId() {
        try {
            ResultSet set = EmployeeModel.getLastId();
            if (set.next()) {
                String[] e0s = set.getString(1).split("E0");
                int id = Integer.parseInt(e0s[1]);
                id++;

                tfEmpId.setText("E0" + id);
            } else {
                tfEmpId.setText("E01");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //    Update User
    public void updateUserOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

        String empId = tfEmpId.getText();
        tfEmpId.setEditable(false);
        String name = tfFName.getText();
        String userName = (tfUserName.getText());
        String password = tfPassword.getText();
        String address = tfAddress.getText();
        String role = String.valueOf(cmbDesignation.getValue());
        int contactNo = Integer.parseInt(tfContact.getText());
        double salary = Double.parseDouble(tfSalary.getText());


        Employee employee = new Employee(empId, name, userName, password, address, role, contactNo, salary);

        boolean isUpdate = EmployeeModel.Update(employee);

        if (isUpdate) {
            new Alert(Alert.AlertType.CONFIRMATION, "User Update Successful...!").show();
            clearTextFields();
            btnclearTextFields.setVisible(false);
        } else {
            new Alert(Alert.AlertType.WARNING, "Something Wrong...!").show();
        }

    }

    //    Delete User
    public void deleteOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {

            boolean isDelete=EmployeeModel.delete(tfEmpId.getText());

            if(isDelete){
                new Alert(Alert.AlertType.CONFIRMATION, "User Deleted Successful...!").show();
                clearTextFields();
                btnclearTextFields.setVisible(false);
            }else {
                new Alert(Alert.AlertType.WARNING, "Something Wrong...!").show();
            }
    }

    //    Search User
    public void tfsearchOnAction(ActionEvent actionEvent) {
        String id = tfEmpId.getText();
        try {
            Employee employee = EmployeeModel.search(id);
            if (employee != null) {
                fillData(employee);
                btnclearTextFields.setVisible(true);
            }else { tfFName.requestFocus();
            lblEMPID.setText("No Employee On This ID");
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    //    Search User Supportive
    public void fillData(Employee employee) {
        tfEmpId.setText(employee.getEmpId());
        tfEmpId.setEditable(false);
        tfFName.setText(employee.getName());
        tfUserName.setText(String.valueOf(employee.getUserName()));
        tfPassword.setText(employee.getPassword());
        tfAddress.setText(employee.getAddress());
        cmbDesignation.setValue(employee.getRole());
        tfContact.setText(String.valueOf(employee.getContactNo()));
        tfSalary.setText(String.valueOf(employee.getSalary()));

    }

    //    Clear Texts
    public void clearOnAction(ActionEvent actionEvent) {
        clearTextFields();
        tfEmpId.setEditable(true);
        btnclearTextFields.setVisible(false);
    }

    //    Log Out
    public void logOutOnAction(ActionEvent actionEvent) throws IOException {
        Navigation.swichNavigation("LoginForm.fxml", actionEvent);

    }

    public void manageSalaryOnAction(ActionEvent actionEvent) {
        userPane.setVisible(false);
        reportPane.setVisible(false);
        imgWelcome.setVisible(false);
        salaryPane.setVisible(true);
    }

    public void manageUserOnAction(ActionEvent actionEvent) {
        imgWelcome.setVisible(false);
        salaryPane.setVisible(false);
        reportPane.setVisible(false);
        userPane.setVisible(true);

    }

    public void reportUserOnAction(ActionEvent actionEvent) {
        userPane.setVisible(false);
        imgWelcome.setVisible(false);
        salaryPane.setVisible(false);
        reportPane.setVisible(true);
    }

    //    Exit
    public void exitOnAction(ActionEvent actionEvent) {
        System.exit(0);
    }

    // Enter btn Actions
    public void txtENameOnAction(ActionEvent actionEvent) { tfAddress.requestFocus();
    }
    public void txtEAddressOnAction(ActionEvent actionEvent) { cmbDesignation.requestFocus();
    }
    public void cmbEDesignationOnAction(ActionEvent actionEvent) { tfContact.requestFocus();
    }
    public void txtContctOnAction(ActionEvent actionEvent) { tfUserName.requestFocus();
    }
    public void txtUserNameOnAction(ActionEvent actionEvent) { tfPassword.requestFocus();
    }
    public void txtPasswordOnAction(ActionEvent actionEvent) { tfSalary.requestFocus();
    }

    ObservableList<EmployeeTM> employeeTMS = FXCollections.observableArrayList();

    private void setTableData() {
        tblManageSalary.getItems().clear();
        try {
            ResultSet set = EmployeeModel.getSalaryDetails();
            while (set.next()){
                employeeTMS.add(new EmployeeTM(
                        set.getString(1),
                        set.getString(2),
                        set.getDouble(3)
                ));
            }
            tblManageSalary.setItems(employeeTMS);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}

