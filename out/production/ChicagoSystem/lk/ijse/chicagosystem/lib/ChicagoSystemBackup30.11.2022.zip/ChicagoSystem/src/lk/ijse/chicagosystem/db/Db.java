package lk.ijse.chicagosystem.db;

import lk.ijse.chicagosystem.view.sm.OrderDetails;

import java.util.ArrayList;

public class Db {
    public static ArrayList<OrderDetails> orderDetails=new ArrayList<>();
}
