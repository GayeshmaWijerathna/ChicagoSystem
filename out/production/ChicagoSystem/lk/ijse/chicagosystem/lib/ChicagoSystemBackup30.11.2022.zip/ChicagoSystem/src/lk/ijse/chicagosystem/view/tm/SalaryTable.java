package lk.ijse.chicagosystem.view.tm;

public class SalaryTable {

    private String empId;
    private String name;
    private double grossSalary;
    private double deductions;
    private double netSalary;

    public SalaryTable(String empId, String name, double grossSalary, double deductions, double netSalary) {
        this.empId = empId;
        this.name = name;
        this.grossSalary = grossSalary;
        this.deductions = deductions;
        this.netSalary = netSalary;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    @Override
    public String toString() {
        return "SalaryTable{" +
                "empId='" + empId + '\'' +
                ", name='" + name + '\'' +
                ", grossSalary=" + grossSalary +
                ", deductions=" + deductions +
                ", netSalary=" + netSalary +
                '}';
    }
}
