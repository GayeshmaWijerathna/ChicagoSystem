package lk.ijse.chicagosystem.util;

public enum Routes {
    DASHBOARD, CUSTOMER, ADMIN, CASHIER, ORDER, REPORTS, SALARY, STOREKEEPER, FEEDBACK
}
